<?php 
/*
Nikolas Ramadhan
203040049
Pertemuan 1 - 04 Maret 2021
*/


$i = 1;
while($i <= 3)
{
	for($j = 1; $j < 4; $j++)
	{
		echo "Ini perulangan ke ($i,$j)<br>";
	}

	$i++;
}
 ?>