'<?php
/*
Nikolas Ramadhan
203040049
 https://github.com/Nikolasramadhan06/pw2021_203040049
 Jumat 10.00-11.00
*/
?>'

<?php 
$kalimat = [
    "ada",
    "abel",
    "men",
    "pung",
    "nilai"
];
echo "Array $kalimat[0]lah suatu vari$kalimat[1] yang dapat $kalimat[2]am$kalimat[3] banyak $kalimat[4]";
?>